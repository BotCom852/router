<template>
  <v-container>
    <center><h2>-</h2></center>
    <center><h1>Product Page</h1></center>
    <v-container class="d-flex flex-wrap">
      <v-card
        class="mx-auto mb-5"
        max-width="400"
        v-for="(i, index) in productlist"
        :key="index"
      >
        <v-img class="white--text align-end" height="300px" :src="i.imageurl">
          <v-card-title>{{ i.name }}</v-card-title>
        </v-img>

        <v-card-subtitle class="pb-0">{{ i.rightText }}</v-card-subtitle>

        <v-card-text class="text--primary">
          <div>{{ i.leftText }}</div>
        </v-card-text>

        <v-card-actions>
          <v-btn color="info" text :to="'/detail/'+i.name">detail</v-btn>
          <v-btn color="orange" text @click="selected(i)"> Add </v-btn>
          
        </v-card-actions>        
      </v-card>
    </v-container>
    <v-container><h4>ยอดชำระเงิน {{total()}} บาท </h4></v-container>
    <v-container grid-list-xs class="dark">
      <router-view :key="$route.path"></router-view>
    </v-container>
  </v-container>
</template>

<script>
export default {
  data() {
    return {
      productlist: [
        {
          name: "ITEM BOX SD51",
          imageurl:
            "https://static.wikia.nocookie.net/battle-spirits/images/e/e8/Siegwurm-Nova_X.jpg",
          rightText: "price : 300",
          leftText: "The SupernovaDragon Siegwurm-NovaX",
          ctaText: "Shop Now",
          active:false,
          price:300,
        },

        {
          name: "ITEM BOX BS25",
          imageurl:
            "https://static.wikia.nocookie.net/battle-spirits/images/d/da/Card_red.png",
          rightText: "price : 50",
          leftText: "The SmallFireDragon Hinoko",
          ctaText: "Shop Now",
          active:false,
          price:50,
        },

        {
          name: "ITEM BOX BS56",
          imageurl:
            "https://static.wikia.nocookie.net/battle-spirits/images/3/3d/I_can%27t_believe_it%27s_not_an_Astral_Dragon.png",
          rightText: "price : 199",
          leftText: "Astroblazer",
          ctaText: "Shop Now",
          active:false,
          price:199,
        },

        {
          name: "ITEM BOX BS31",
          imageurl:
            "https://static.wikia.nocookie.net/battle-spirits/images/b/bb/BS31-X05.png",
          rightText: "price : 100",
          leftText: "The SengokuPrincess Nayuta",
          ctaText: "Shop Now",
          active:false,
          price:100,
        },

        {
          name: "ITEM BOX BSC37",
          imageurl:
            "https://static.wikia.nocookie.net/battle-spirits/images/8/85/BSC37-005.png",
          rightText: "price : 250",
          leftText: "Fallen War Princess Sierra-Murceine",
          ctaText: "Shop Now",
          active:false,
          price:250,
        },

        {
          name: "ITEM BOX BSC37",
          imageurl:
            "https://static.wikia.nocookie.net/battle-spirits/images/6/64/BSC37-006.png",
          rightText: "price : 250",
          leftText: "Witch Quartet Noir Flamme-Sandria",
          ctaText: "Shop Now",
          active:false,
          price:250,
        },

        {
          name: " ITEM BOX BSC37",
          imageurl:
            "https://static.wikia.nocookie.net/battle-spirits/images/6/6c/Lilia.png",
          rightText: "price : 100",
          leftText: "Magnolilia-Miser",
          ctaText: "Shop Now",
          active:false,
          price:100,
        },

        {
          name: "ITEM BOX BS43",
          imageurl:
            "https://static.wikia.nocookie.net/battle-spirits/images/3/3f/BS43-XX01.png",
          rightText: "price : 150",
          leftText: "The ClownDeity Trickster",
          ctaText: "Shop Now",
          active:false,
          price:150,
        },

        {
          name: "ITEM BOX M039",
          imageurl:
            "https://static.wikia.nocookie.net/battle-spirits/images/6/6b/BS12-039_500x730.jpg",
          rightText: "price : 50",
          leftText: "The ClownPrincess Trickster",
          ctaText: "Shop Now",
          active:false,
          price:50,
        },

        {
          name: "ITEM BOX P045",
          imageurl:
            "https://static.wikia.nocookie.net/battle-spirits/images/d/db/The_ClowPrincess_Blackster.jpg",
          rightText: "price : 50",
          leftText: "The ClownPrincess Blackster",
          ctaText: "Shop Now",
          active:false,
          price:50,
        },

      
      ],
    };
  },
  methods:{
    selected:function(i){
        i.active = !i.active
    },
    total:function(){
        var sum=0;
        this.productlist.forEach(function(i){
              if(i.active){
                  sum+=i.price; 
              }
        });
        return sum;
    }
  }
};
</script>

<style>
h2{
  color: rgb(253, 249, 249);
}
</style>
